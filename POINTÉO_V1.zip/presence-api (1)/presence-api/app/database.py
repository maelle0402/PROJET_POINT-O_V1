from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

# Informations de connexion à SQL Server
server = "DESKTOP-3G0MPTR\\SQLEXPRESS"
database = "PresenceDB"
username = "sa"
password = "Miage2025!"

# Chaîne de connexion ODBC
connection_string = (
    f"mssql+pyodbc://{username}:{password}@{server}/{database}?driver=ODBC+Driver+17+for+SQL+Server"
)

# Création de l'engine SQLAlchemy
engine = create_engine(connection_string)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base pour les modèles
Base = declarative_base()
