const presences = [
  { date: "2024-06-14", cours: "Mathématiques Avancées", prof: "Dr. Martin", statut: "present", heure: "08:15" },
  { date: "2024-06-14", cours: "Physique Quantique", prof: "Prof. Dubois", statut: "retard", heure: "10:35" },
  { date: "2024-05-30", cours: "Chimie Organique", prof: "Dr. Rousseau", statut: "present", heure: "14:05" },
  { date: "2024-04-28", cours: "Économie Numérique", prof: "Mme. Simon", statut: "absent", heure: "16:00" },
  { date: "2024-01-10", cours: "Programmation", prof: "Mr. Lemoine", statut: "present", heure: "09:00" },
];

const tbody = document.getElementById("presence-body");
const periodeSelect = document.getElementById("periode-filter");
const statutSelect = document.getElementById("statut-filter");

function filterPresences() {
  const periode = periodeSelect.value;
  const statut = statutSelect.value;
  const now = new Date();

  tbody.innerHTML = "";

  presences.forEach(p => {
    const dateCours = new Date(p.date);
    let show = true;

    // Période
    if (periode === "mois") {
      show = dateCours.getMonth() === now.getMonth() && dateCours.getFullYear() === now.getFullYear();
    } else if (periode === "semestre") {
      const currentMonth = now.getMonth();
      const startMonth = currentMonth < 6 ? 0 : 6;
      show = (dateCours.getMonth() >= startMonth && dateCours.getMonth() < startMonth + 6) &&
             (dateCours.getFullYear() === now.getFullYear());
    } else if (periode === "annee") {
      show = dateCours.getFullYear() === now.getFullYear();
    }

    // Statut
    if (statut !== "all" && p.statut !== statut) {
      show = false;
    }

    if (show) {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td style="padding: 0.75rem;">${new Date(p.date).toLocaleDateString('fr-FR')}</td>
        <td>${p.cours}</td>
        <td>${p.prof}</td>
        <td><span class="status ${p.statut}" style="padding: 0.3rem 0.6rem; border-radius: 12px;">
          ${p.statut.charAt(0).toUpperCase() + p.statut.slice(1)}
        </span></td>
        <td>${p.heure}</td>
      `;
      tbody.appendChild(row);
    }
  });
}

periodeSelect.addEventListener("change", filterPresences);
statutSelect.addEventListener("change", filterPresences);
document.addEventListener("DOMContentLoaded", filterPresences);
