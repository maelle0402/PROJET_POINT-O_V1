from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from app.routers import user
from app.routers import classes
from app.routers import cours
from app.routers import cours_classes
from app.routers import presence
from app.routers import roles

app = FastAPI()

app.include_router(user.router)

app.include_router(classes.router)
app.include_router(cours.router)
app.include_router(cours_classes.router)
app.include_router(presence.router)
app.include_router(roles.router)
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Bienvenue sur l'API de présence"}
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
import os

app = FastAPI()

# Monter les fichiers statiques
app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")

