from sqlalchemy import Column, Integer, String
from app.database import Base

class Classe(Base):
    __tablename__ = "classes"

    id = Column(Integer, primary_key=True, index=True)
    nom = Column(String(100), nullable=False)  # ex : BTS SIO 1A
    niveau = Column(String(50), nullable=True)  # ex : L3, 1ère année
    annee_scolaire = Column(String(20), nullable=True)  # ex : 2024-2025
