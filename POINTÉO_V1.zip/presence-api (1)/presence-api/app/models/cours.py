from sqlalchemy import Column, Integer, String, DateTime
from app.database import Base

class Cours(Base):
    __tablename__ = "cours"

    id = Column(Integer, primary_key=True, index=True)
    titre = Column(String(100), nullable=False)
    date_heure = Column(DateTime, nullable=False)

