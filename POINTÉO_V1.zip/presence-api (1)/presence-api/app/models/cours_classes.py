from sqlalchemy import Column, Integer, ForeignKey
from app.database import Base

class CoursClasse(Base):
    __tablename__ = "cours_classes"

    id = Column(Integer, primary_key=True, index=True)
    cours_id = Column(Integer, ForeignKey("cours.id"), nullable=False)
    classe_id = Column(Integer, ForeignKey("classes.id"), nullable=False)
