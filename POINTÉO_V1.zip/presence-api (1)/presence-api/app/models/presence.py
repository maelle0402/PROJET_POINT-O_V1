from sqlalchemy import Column, Integer, Boolean, ForeignKey
from app.database import Base

class Presence(Base):
    __tablename__ = "presence"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("utilisateurs.id"), nullable=False)
    cours_id = Column(Integer, ForeignKey("cours.id"), nullable=False)
    present = Column(Boolean, nullable=False)


