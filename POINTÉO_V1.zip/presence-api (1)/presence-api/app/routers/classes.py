from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models.classes import Classe
from app.schemas.classes import ClasseCreate, ClasseRead

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/classes", response_model=list[ClasseRead])
def get_classes(db: Session = Depends(get_db)):
    return db.query(Classe).all()

@router.post("/classes", response_model=ClasseRead)
def create_classe(classe: ClasseCreate, db: Session = Depends(get_db)):
    db_classe = Classe(**classe.dict())
    db.add(db_classe)
    db.commit()
    db.refresh(db_classe)
    return db_classe
