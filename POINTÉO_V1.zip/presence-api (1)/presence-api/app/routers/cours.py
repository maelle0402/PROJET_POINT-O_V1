from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models.cours import Cours
from app.schemas.cours import CoursCreate, CoursRead

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/cours", response_model=list[CoursRead])
def get_all_cours(db: Session = Depends(get_db)):
    return db.query(Cours).all()

@router.get("/cours/{cours_id}", response_model=CoursRead)
def get_cours_by_id(cours_id: int, db: Session = Depends(get_db)):
    cours = db.query(Cours).filter(Cours.id == cours_id).first()
    if not cours:
        raise HTTPException(status_code=404, detail="Cours non trouvé")
    return cours

@router.post("/cours", response_model=CoursRead)
def create_cours(cours: CoursCreate, db: Session = Depends(get_db)):
    db_cours = Cours(**cours.dict())
    db.add(db_cours)
    db.commit()
    db.refresh(db_cours)
    return db_cours
