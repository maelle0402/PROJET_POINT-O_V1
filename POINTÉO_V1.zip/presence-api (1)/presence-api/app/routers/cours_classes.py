from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models.cours_classes import CoursClasse
from app.schemas.cours_classes import CoursClasseCreate, CoursClasseRead

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/cours-classes", response_model=list[CoursClasseRead])
def get_all_cours_classes(db: Session = Depends(get_db)):
    return db.query(CoursClasse).all()

@router.get("/cours-classes/{id}", response_model=CoursClasseRead)
def get_cours_classe_by_id(id: int, db: Session = Depends(get_db)):
    result = db.query(CoursClasse).filter(CoursClasse.id == id).first()
    if not result:
        raise HTTPException(status_code=404, detail="Association non trouvée")
    return result

@router.post("/cours-classes", response_model=CoursClasseRead)
def create_cours_classe(data: CoursClasseCreate, db: Session = Depends(get_db)):
    db_entry = CoursClasse(**data.dict())
    db.add(db_entry)
    db.commit()
    db.refresh(db_entry)
    return db_entry
