from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models.presence import Presence
from app.schemas.presence import PresenceCreate, PresenceRead

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/presence", response_model=list[PresenceRead])
def get_presence(db: Session = Depends(get_db)):
    return db.query(Presence).all()

@router.post("/presence", response_model=PresenceRead)
def create_presence(presence: PresenceCreate, db: Session = Depends(get_db)):
    db_presence = Presence(**presence.dict())
    db.add(db_presence)
    db.commit()
    db.refresh(db_presence)
    return db_presence
