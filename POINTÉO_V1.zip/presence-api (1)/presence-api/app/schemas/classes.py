from pydantic import BaseModel

class ClasseCreate(BaseModel):
    nom: str
    niveau: str | None = None
    annee_scolaire: str | None = None

class ClasseRead(ClasseCreate):
    id: int

    class Config:
        orm_mode = True
