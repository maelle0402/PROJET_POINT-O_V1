from pydantic import BaseModel
from datetime import datetime

class CoursCreate(BaseModel):
    titre: str
    date_heure: datetime

class CoursRead(CoursCreate):
    id: int

    class Config:
        orm_mode = True
