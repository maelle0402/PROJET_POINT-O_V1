from pydantic import BaseModel

class CoursClasseCreate(BaseModel):
    cours_id: int
    classe_id: int

class CoursClasseRead(CoursClasseCreate):
    id: int

    class Config:
        orm_mode = True
