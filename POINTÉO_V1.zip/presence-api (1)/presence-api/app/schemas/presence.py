from pydantic import BaseModel

class PresenceCreate(BaseModel):
    user_id: int
    cours_id: int
    present: bool

class PresenceRead(BaseModel):
    id: int
    user_id: int
    cours_id: int
    present: bool

    class Config:
        from_attributes = True
