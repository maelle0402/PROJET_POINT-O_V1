from pydantic import BaseModel

class RoleCreate(BaseModel):
    nom: str

class RoleRead(RoleCreate):
    id: int

    class Config:
        orm_mode = True
