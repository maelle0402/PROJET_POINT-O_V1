from pydantic import BaseModel, EmailStr

class UserCreate(BaseModel):
    nom: str
    email: EmailStr
    mot_de_passe: str
    role_id: int
    classe_id: int | None = None

class UserRead(UserCreate):
    id: int

    class Config:
        orm_mode = True
